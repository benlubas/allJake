const makeMove = (pos, radius, ...astroids) => {
  let threats = [];
  let priorities = [];
  for (a of astroids) {
    if (a.pos.dist(pos) <= radius * 2) {
      threats.push(a);
    }
    if (a.pos.dist(pos) <= radius + 1) {
      priorities.push(a);
    }
  }
  if (threats.legnth === 0) {
    return { x: 0, y: 0 };
  }
  for (p of priorities) {
    p.pos.getQuadrent(pos);
  }
};
